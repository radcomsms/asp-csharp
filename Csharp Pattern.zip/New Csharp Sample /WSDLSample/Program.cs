﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace WSDLSample
{
    class Program
    {
        static void Main(string[] args)
        {
            PanelSMS.smsserver client = new PanelSMS.smsserver();
            var username = "";
            var password = "";
            var fromNum = "";
            string[] toNum = { "" };

            var patternCode = "119";


            var data = new PanelSMS.input_data_type[] {
                // key is your parameter name and value is what you want to send to the receiptor 
                new PanelSMS.input_data_type(){ key ="customer-name",value ="21981" } ,
                new PanelSMS.input_data_type(){ key ="number",value ="321233fds" }
            };

            var response = client.sendPatternSms(fromNum, toNum, username, password, patternCode, data);


            Console.WriteLine(response);
        }
    }
}
